enum UserType {
  user,
  customer,
  admin,
  // ignore: constant_identifier_names
  delivery_man,
  vendor,
}

enum Types {
  simple,
  slideSwiper,
  xRotating,
  yRotating,
  zRotating,
  multiRotating
}
// enum IndicatorTypes { bar, dot, bubble }

// enum OrderStatusType {
//   pending,
//   accepted,
//   processing,
//   confirmed,
//   handover,
//   // ignore: constant_identifier_names
//   picked_up,
// }