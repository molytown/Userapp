package com.mogomunch.munch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
